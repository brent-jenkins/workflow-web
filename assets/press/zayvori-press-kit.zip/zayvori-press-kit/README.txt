﻿ZAYVORI PRESS KIT
https://zayvori.com/press.html

KEY FACTS
App: Zayvori: Next-Step To-Do List
Say it: zay-VOR-ee. One word, capital Z only.
What it is: A to-do list for big jobs that hides what can’t be done yet and shows only your next steps
Platform: Android phones, tablets and foldables, on Google Play
Launched: 21 November 2026
Price: Free. Zayvori Premium adds AI planning and calendar sync for $2.99 a month or $29.99 a year in the US (local prices vary), with a 7-day free trial.
Languages: English, Spanish, Portuguese, French, German, Italian, Indonesian, Japanese, Traditional Chinese and Korean
Privacy: No account, works offline, plans stay on the phone, no ads or tracking. The Premium AI features send only what you ask for to draft the steps, and nothing is kept.
Made by: An independent developer, trading as Zayvori
Press contact: support@zayvori.com
Links: zayvori.com · x.com/zayvoriapp · youtube.com/@zayvoriapp · tiktok.com/@zayvori_app · pinterest.com/zayvoriapp

DESCRIPTIONS

IN ONE LINE
Zayvori is a to-do list for big jobs that hides what can’t be done yet and shows only your next steps.

SHORT (ABOUT 60 WORDS)
Zayvori is a to-do list app for Android built for jobs with lots of moving parts: a move, a kitchen remodel, an event. Instead of one long list, each plan knows which tasks are waiting for others, so Zayvori shows only what you can do right now. Check one off and the next steps appear. It’s free, needs no account and keeps your plans on your phone.

LONGER (ABOUT 170 WORDS)
Most to-do apps show every task at once and leave you to work out what can actually happen next. Zayvori, which launched on Google Play in November 2026, does the opposite: build a plan once, and it keeps track of what’s waiting for what, showing only your next steps.

Plans can split, run side by side and come back together, with room for a plan B. Waiting on two contractor quotes? The first one back moves the job forward, and the other is set aside automatically. A map shows the whole job at a glance, the Today tab gathers what’s due across every plan, and reminders let you check things off right from the notification.

Zayvori Premium adds AI planning: describe a plan in a sentence, such as “Christmas dinner for 8, on the table at 2pm,” and it drafts the steps, order and timings for you to look over. Everything else is free. The app works offline, needs no account, keeps plans on the phone and has no ads or tracking. It’s available in ten languages.

WHAT MAKES IT DIFFERENT
- Only your next steps. Tasks that are waiting on something stay out of the way until they’re ready, so the list is always things you can do now.
- Room for a plan B. Mark a step “any one is enough”: the first route that’s done moves the plan on, and the others are set aside by themselves.
- Plans in a sentence (Premium). Type or say what you need to do and by when. Claude, an AI from Anthropic, drafts the plan by the day or by the hour, for you to check before you begin.
- Private by design. No account and no server holding your plans. Backups are a file you keep wherever you like.

IN THIS FOLDER
logo/        app icon (1024 PNG), the mark (SVG), banner (1024 x 500 PNG)
screenshots/ real screens from the app in English, 640 x 1436, and a tablet screen 1600 x 900
video/       an 18-second screen recording of Describe it, no sound

Please do not recolor or stretch the mark. Brand colors: violet #6A4DFF to magenta #C34DFF, mint #2BD99F.
Press contact: support@zayvori.com
